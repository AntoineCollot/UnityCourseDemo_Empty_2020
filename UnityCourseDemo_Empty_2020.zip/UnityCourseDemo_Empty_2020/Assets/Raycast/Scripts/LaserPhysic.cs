﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaserPhysic : MonoBehaviour {

    public Vector3 hitPoint;

    public float hitDistance;

    void Awake()
    {

    }
	
	// Update is called once per frame
	void Update () {

    }
}
